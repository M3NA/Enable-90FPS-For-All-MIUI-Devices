mkdir $MODPATH/test
cp system/product/etc/device_features/*.xml $MODPATH/test/